function greet() {
  var name = document.getElementById("name").value;
  document.getElementById("msg").innerHTML = "Welcome, " + name + "!";
  console.log("User name: " + name);
}